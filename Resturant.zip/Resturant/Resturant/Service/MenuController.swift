//
//  NetworkService.swift
//  Resturant
//
//  Created by Dante Ausonio on 3/3/23.
//

import Foundation
import UIKit

class MenuController {
    
    static let shared = MenuController()
    static let orderUpdatedNotification = Notification.Name("MenuController.orderUpdated")
    
    let baseURL = URL(string: "http://localhost:8080/")
    typealias minutesToPrepare = Int
    
    
    var order = Order() {
        didSet {
            NotificationCenter.default.post(name: MenuController.orderUpdatedNotification, object: nil)
        }
    }
    
    
    func fetchCategories(completion: @escaping (Result<[String], Error>) -> Void) {
        let categoriesURL = baseURL?.appending(path: "categories")
        
        let task = URLSession.shared.dataTask(with: categoriesURL!) { data, response, error in
            let jsonDecoder = JSONDecoder()
            if let data = data {
                do {
                    let categoriesResponse = try jsonDecoder.decode(CategoriesResponse.self, from: data)
                    completion(.success(categoriesResponse.categories))
                } catch {
                    completion(.failure(error))
                }
            } else if let error = error {
                completion(.failure(error))
            }
        }
        task.resume()
    }
    
    
    func fetchMenu(category: String, completion: @escaping (Result<[MenuItem], Error>) -> Void) {
        let queryItem = URLQueryItem(name: "category", value: category)
        let menuURL = baseURL?.appending(path: "menu").appending(queryItems: [queryItem])
        
        let task = URLSession.shared.dataTask(with: menuURL!) { data, response, error in
            let jsonDecoder = JSONDecoder()
            if let data = data {
                do {
                    let menuResponse: MenuResponse = try jsonDecoder.decode(MenuResponse.self, from: data)
                    completion(.success(menuResponse.items))
                } catch {
                    completion(.failure(error))
                }
            } else if let error = error {
                completion(.failure(error))
            }
        }
        task.resume()
    }
    
    
    func submitOrder(forMenuIDs menuIDs: [Int], completion: @escaping (Result<minutesToPrepare, Error>) -> Void) {
        let orderURL = baseURL?.appending(path: "order")
        var request = URLRequest(url: orderURL!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let data = ["menuIds" : menuIDs]
        let jsonEncoder = JSONEncoder()
        let jsonData = try? jsonEncoder.encode(data)
        
        request.httpBody = jsonData
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let data = data {
                do {
                    let jsonDecoder = JSONDecoder()
                    let orderResponse: OrderResponse = try jsonDecoder.decode(OrderResponse.self, from: data)
                    completion(.success(orderResponse.prepTime))
                } catch {
                    completion(.failure(error))
                }
            } else if let error = error {
                print(error)
            }
        }
        task.resume()
    }
    
    
    
    func fetchImage(url: URL, completion: @escaping (UIImage?)
       -> Void) {
        let urlStr = url.absoluteString.replacingOccurrences(of: ".png", with: "")
        let newURL = URL(string: urlStr)
        print(newURL)
        let task = URLSession.shared.dataTask(with: newURL!)
               { (data, response, error) in
                   print(newURL)
                   if let data = data {
                       print("Data Success")
                       if let image = UIImage(data: data) {
                           print("image success")
                           completion(image)
                       } else {
                           print("image failure")
                       }
                } else {
                    print("Data Failure")
                    completion(nil)
                }
            }
            task.resume()
    }
    
    
}
