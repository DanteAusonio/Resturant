//
//  MenuTVC.swift
//  Resturant
//
//  Created by Dante Ausonio on 3/3/23.
//

import UIKit

class MenuTVC: UITableViewController {

    var category: String = ""
    var menuItems = [MenuItem]()
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = category.capitalized
        
        MenuController.shared.fetchMenu(category: category) { Result in
            switch Result {
            case .success(let menuItems):
                self.updateUI(with: menuItems)
            case .failure(let error):
                self.displayError(for: error)
            }
        }
        
    }
    
    
    func updateUI(with menuItems: [MenuItem]) {
        DispatchQueue.main.async {
            self.menuItems = menuItems
            self.tableView.reloadData()
        }
    }

    
    func displayError(for error: Error) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alert, animated: true)
        }
    }
    
    
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return menuItems.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuItem", for: indexPath)
        configure(cell, forItemAt: indexPath)
        return cell
    }
    
    
    
    func configure(_ cell: UITableViewCell, forItemAt indexPath:
       IndexPath) {
        let menuItem = menuItems[indexPath.row]
        cell.textLabel?.text = menuItem.name
        cell.detailTextLabel?.text =
           MenuItem.priceFormatter.string(from: NSNumber(value:
           menuItem.price))
        MenuController.shared.fetchImage(url: menuItem.imageURL)
           { (image) in
               guard image != nil else { return }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? MenuItemDetailVC {
            guard let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) else { return }
            destination.menuItem = menuItems[indexPath.row]
        }
    }
}
