//
//  CategoriesTVC.swift
//  Resturant
//
//  Created by Dante Ausonio on 3/3/23.
//

import UIKit

class CategoriesTVC: UITableViewController {

    var categories = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        MenuController.shared.fetchCategories { Result in
            switch Result {
            case .success(let categories):
                self.updateUI(with: categories)
            case .failure(let error):
                self.displayError(for: error)
            }
        }
    }
    
    
    func updateUI(with categories: [String]) {
        DispatchQueue.main.async {
            self.categories = categories
            self.tableView.reloadData()
        }
    }
    
    
    func displayError(for error: Error) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alert, animated: true)
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? MenuTVC {
            guard let cell = sender as? UITableViewCell, let indexPath = tableView.indexPath(for: cell) else { return }
            destination.category = categories[indexPath.row]
        }
    }
    
    
    
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return categories.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Category", for: indexPath)
        let category = categories[indexPath.row]
        cell.textLabel?.text = category.capitalized
        return cell
    }

}
